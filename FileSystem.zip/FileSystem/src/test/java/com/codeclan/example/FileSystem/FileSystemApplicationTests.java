package com.codeclan.example.FileSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
